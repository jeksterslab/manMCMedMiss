# manMCMedMiss 0.9.2

## Major changes

* This is the version with results.

# manMCMedMiss 0.9.1

## Major changes

* This is the version used in the simulations.
